package com.exmple.web.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import com.exmple.web.model.CompUsers;

@Mapper
public interface CompUsersMapper {
	
	  @Select("SELECT * FROM comp_users WHERE username = #{username}")
	  public CompUsers findByUsername(String username);
	  
}
