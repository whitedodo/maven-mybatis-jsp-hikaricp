package com.exmple.web.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import com.exmple.web.db.SqlMapSessionFactory;
import com.exmple.web.mapper.CompUsersMapper;
import com.exmple.web.model.CompUsers;

public class FrontController extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
    SqlSessionFactory factory = SqlMapSessionFactory.getSqlSessionFactory();

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doAction(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doAction(request, response);
	}

	
	protected void doAction(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		try (SqlSession session = factory.openSession()) {
		  CompUsersMapper mapper = session.getMapper(CompUsersMapper.class);
		  CompUsers user = mapper.findByUsername("user");
		  
		  System.out.println("계정명:" + user.getUsername());
		  
		}
		
	}

}
