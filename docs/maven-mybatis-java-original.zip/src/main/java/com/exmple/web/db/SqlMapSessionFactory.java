package com.exmple.web.db;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.mapping.Environment;
import org.apache.ibatis.session.Configuration;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.apache.ibatis.transaction.TransactionFactory;
import org.apache.ibatis.transaction.jdbc.JdbcTransactionFactory;

import com.exmple.web.mapper.CompUsersMapper;

import oracle.jdbc.pool.OracleDataSource;

public class SqlMapSessionFactory {

	private static SqlMapSessionFactory factory = new SqlMapSessionFactory();

	private SqlMapSessionFactory() {}

	private final static String driverName = "oracle.jdbc.driver.OracleDriver";
	private final static String dbUrl = "jdbc:oracle:thin:@127.0.0.1:1521:orcl";
	private final static String userName = "사용자계정명";
	private final static String userPassword = "비밀번호";

	public static SqlMapSessionFactory getInstance() {
		return factory;
	}
	

	public static SqlSessionFactory ssf;

    static{

    	DataSource dataSource = getOracleDataSource();
    	TransactionFactory transactionFactory = new JdbcTransactionFactory();
    	
    	Environment environment = new Environment("development", transactionFactory, dataSource);
    	Configuration configuration = new Configuration(environment);
    	
    	configuration.addMapper(CompUsersMapper.class);		// Mapper 클래스
    	
        ssf = new SqlSessionFactoryBuilder().build(configuration);
        
    }
    
	// iBatis(MyBatis 반환)
	public static SqlSessionFactory getSqlSessionFactory(){
        return ssf;
    }

	/*

	 *     public static DataSource getMySQLDataSource() {
        Properties props = new Properties();

        FileInputStream fis = null;
        MysqlDataSource mysqlDS = null;
        
        try {
            fis = new FileInputStream("db.properties");

            props.load(fis);
            mysqlDS = new MysqlDataSource();
            mysqlDS.setURL(props.getProperty("MYSQL_DB_URL"));
            mysqlDS.setUser(props.getProperty("MYSQL_DB_USERNAME"));
            mysqlDS.setPassword(props.getProperty("MYSQL_DB_PASSWORD"));
            
        } catch (IOException e) {
            e.printStackTrace();
        }
        return mysqlDS;
        
    }
    */
	
	/*
	 * Description: 순정 오라클 데이터소스
	 */
    private static DataSource getOracleDataSource(){
        
    	OracleDataSource oracleDS = null;
        
    	try {
            oracleDS = new OracleDataSource();
            oracleDS.setURL(dbUrl);
            oracleDS.setUser(userName);
            oracleDS.setPassword(userPassword);
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
    	
        return oracleDS;

    }

	public Connection connect() {

		Connection conn = null;

		try {
			Class.forName(driverName);
			conn = DriverManager.getConnection(dbUrl, userName, userPassword);
		}
		catch(Exception ex) {
			System.out.println("오류 발생: " + ex);
		}
		return conn;
		
	}

	public void close(Connection conn, PreparedStatement ps, ResultSet rs) {

		if ( rs != null ) {

			try {
				rs.close();
			}
			catch(Exception ex) {
				System.out.println("오류 발생: " + ex);
			}
			
			close(conn, ps);	// Recursive 구조 응용(재귀 함수)
		} // end of if

	}	

	public void close(Connection conn, PreparedStatement ps) {

		if (ps != null ) {
			try {
				ps.close();
			}
			catch(Exception ex) {
				System.out.println("오류 발생: " + ex);
			}
		} // end of if

		if (conn != null ) {

			try {
				conn.close();
			}
			catch(Exception ex) {
				System.out.println("오류 발생: " + ex);
			}

		} // end of if

	}

}